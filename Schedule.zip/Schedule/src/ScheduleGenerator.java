import java.util.*;

public class ScheduleGenerator{
    private List<String> subject;

    public ScheduleGenerator(List<String> subjects) {
        this.subject = subjects;
    }

    /*
     * Generuje náhodný rozvrh předmětů.
     * Metoda vytváří rozvrh o délce 12 hodin, kde každá hodina obsahuje náhodně vybraný předmět
     * ze seznamu předmětů, který je předán jako vstupní parametr nebo definován v třídě.
     *
     * @return Seznam předmětů reprezentující náhodně vygenerovaný rozvrh.
     */
    public List<String> generateSchedule() {
        // Inicializace generátoru náhodných čísel
        Random rand = new Random();

        // Inicializace seznamu pro ukládání rozvrhu
        List<String> schedule = new ArrayList<>();

        // Pro každou hodinu v rozvrhu (50 hodin)
        for (int j = 0; j < 50; j++) {
            // Zamíchejte seznam předmětů
            Collections.shuffle(subject);

            // Vygenerujte náhodné číslo reprezentující index některého z předmětů
            int numSub = rand.nextInt(subject.size());

            // Přidejte náhodný předmět do rozvrhu
            schedule.add(subject.get(numSub));
        }

        // Vrácení náhodně vygenerovaného rozvrhu
        return schedule;
    }

}

