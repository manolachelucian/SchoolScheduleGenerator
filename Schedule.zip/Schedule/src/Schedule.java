

public class Schedule {

    private String subjects;
    private String teachers;

    private String classRoom;

    public Schedule(String subject,String teacher,String classRoom){
        this.subjects = subject;
        this.teachers = teacher;
        this.classRoom = classRoom;
    }


    public String getSubjects(){
        return  subjects;
    }
    public String getTeachers(){
        return  teachers;
    }
    public String getClassRoom(){
        return  classRoom;
    }

    @Override
    public String toString(){
        return "Predmet:"+subjects+", Ucitel/ka: "+teachers+", Classroom: "+classRoom;
    }


}
