import java.util.ArrayList;

import java.util.List;

public class Main {
    public static void main(String[] args){
        long timeout = 10000; // Timeout v milisekundách (např. 3 sekundy)
        Watchdog watchdog = new Watchdog(timeout);
        ArrayList<String> subjects = new ArrayList<>();
        subjects.add("Ma");
        subjects.add("Tv");
        subjects.add("DS");
        subjects.add("PV");
        subjects.add("PSS");
        subjects.add("Cit");
        subjects.add("TP");
        subjects.add("AM");
        subjects.add("None");
        subjects.add("Aj");
        subjects.add("Cj");
        subjects.add("WA");
        subjects.add("PiS");

        /// Vytvoření instance ScheduleGenerator s danými předměty
        ScheduleGenerator scheduleGenerator = new ScheduleGenerator(subjects);

        // Generování rozvrhu
        List<String> timetable = scheduleGenerator.generateSchedule();

        // Vytvoření instance třídy PermutationGenerator pro každé vlákno s daným rozvrhem
        PermutationGenerator generatorThread1 = new PermutationGenerator(timetable);
        PermutationGenerator generatorThread2 = new PermutationGenerator(timetable);
        PermutationGenerator generatorThread3 = new PermutationGenerator(timetable);

        // Vytvoření instancí vláken pro každý generátor permutací
        Thread thread1 = new Thread(generatorThread1);
        Thread thread2 = new Thread(generatorThread2);
        Thread thread3 = new Thread(generatorThread3);

        // Spuštění prvního vlákna
        thread1.start();
        thread2.start();
        thread3.start();

        // Spustíme watchdog
        watchdog.start();

        try {
            // Čekání na dokončení prvního vlákna nebo timeout watchdogu
            thread1.join(timeout);
            thread2.join(timeout);
            thread3.join(timeout);
            // Zastavíme watchdog
            watchdog.stop();

            // Získání výsledků prvního vlákna
            int uniquePermutationsCount1 = generatorThread1.getUniquePermutationsCount();
            int uniquePermutationsCount2 = generatorThread2.getUniquePermutationsCount();
            int uniquePermutationsCount3 = generatorThread3.getUniquePermutationsCount();

            // Vypsání výsledků prvního vlákna
            System.out.println("Thread 1  " + uniquePermutationsCount1);
            System.out.println("Thread 2  " + uniquePermutationsCount2);
            System.out.println("Thread 3  " + uniquePermutationsCount3);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}