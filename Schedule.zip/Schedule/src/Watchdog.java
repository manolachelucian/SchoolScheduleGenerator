import java.util.Timer;
import java.util.TimerTask;

public class Watchdog {
    private Timer timer;
    private long timeoutInMillis;
    private boolean timeoutOccurred;

    /**
     * Konstruktor pro Watchdog.
     *
     * @param timeoutInMillis Časový limit pro timeout (v milisekundách).
     */
    public Watchdog(long timeoutInMillis) {
        this.timer = new Timer(true); // Daemon thread
        this.timeoutInMillis = timeoutInMillis;
        this.timeoutOccurred = false;
    }

    /**
     * Spustí sledování timeoutu.
     */
    public void start() {
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                timeoutOccurred = true;
                timer.cancel(); // Zastavíme timer
            }
        }, timeoutInMillis);
    }

    /**
     * Zastaví sledování timeoutu.
     */
    public void stop() {
        timer.cancel(); // Zastavíme timer
    }

    /**
     * Vrátí informaci o tom, zda došlo k timeoutu.
     *
     * @return True, pokud došlo k timeoutu, jinak false.
     */
    public boolean timeoutOccurred() {
        return timeoutOccurred;
    }
}
