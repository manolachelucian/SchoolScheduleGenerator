import java.util.*;

public class PermutationGenerator implements Runnable {
    private List<String> originalList;
    private int uniquePermutationsCount;

    public PermutationGenerator(List<String> originalList) {
        this.originalList = originalList;
    }

    public int getUniquePermutationsCount() {
        return uniquePermutationsCount;
    }

    public void run() {
        try {
            // Inicializace množiny pro ukládání unikátních permutací
            Set<List<String>> uniquePermutations = new HashSet<>();

            // Volání pomocné metody pro generování permutací
            countUniquePermutationsHelper(originalList, 0, uniquePermutations);

            // Nastavení počtu unikátních permutací
            uniquePermutationsCount = uniquePermutations.size();
        } catch (Exception e) {
            // Zpracování chyby a vytvoření nové výjimky s chybovým hlášením
            throw new RuntimeException("Chyba při generování permutací.", e);
        }
    }
    /*
     * Pomocná metoda pro rekurzivní generování všech unikátních permutací v zadaném seznamu.
     *
     * @param originalList Seznam, pro který jsou generovány permutace.
     * @param index Aktuální index v procesu generování permutací.
     * @param uniquePermutations Množina pro ukládání unikátních permutací.
     */
    private static void countUniquePermutationsHelper(List<String> originalList, int index, Set<List<String>> uniquePermutations) {
        // Kontrola, zda je dosaženo posledního prvku v seznamu
        if (index == originalList.size() - 1) {
            // Přidání nové permutace do množiny
            uniquePermutations.add(new ArrayList<>(originalList));
            return;
        }

        // Rekurzivní generování permutací pro zbývající část seznamu
        for (int i = index; i < originalList.size(); i++) {
            // Prohození prvků na aktuálním a vybraném indexu
            swap(originalList, index, i);

            // Rekurzivní volání pro generování permutací pro zbývající část seznamu
            countUniquePermutationsHelper(originalList, index + 1, uniquePermutations);

            // Zpětná výměna pro návrat do původního stavu před dalším průchodem cyklem
            swap(originalList, index, i);
        }
    }

    /*
     * Metoda pro výměnu prvků na zadaných pozicích v seznamu.
     *
     * @param list Seznam, ve kterém proběhne výměna prvků.
     * @param i Index prvního prvku pro výměnu.
     * @param j Index druhého prvku pro výměnu.
     * @throws IndexOutOfBoundsException Pokud jsou indexy mimo rozsah seznamu.
     */
    private static void swap(List<String> list, int i, int j) {
        // Uložení hodnoty prvního prvku do dočasné proměnné
        String temp = list.get(i);

        // Přepsání prvního prvku hodnotou druhého prvku
        list.set(i, list.get(j));

        // Přepsání druhého prvku hodnotou dočasné proměnné (původní hodnota prvního prvku)
        list.set(j, temp);
    }
}
